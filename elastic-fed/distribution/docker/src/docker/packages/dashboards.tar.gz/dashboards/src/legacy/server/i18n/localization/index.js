"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "registerLocalizationUsageCollector", {
  enumerable: true,
  get: function () {
    return _telemetry_localization_collector.registerLocalizationUsageCollector;
  }
});

var _telemetry_localization_collector = require("./telemetry_localization_collector");