"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "timelineSheetSavedObjectType", {
  enumerable: true,
  get: function () {
    return _timeline_sheet.timelineSheetSavedObjectType;
  }
});

var _timeline_sheet = require("./timeline_sheet");