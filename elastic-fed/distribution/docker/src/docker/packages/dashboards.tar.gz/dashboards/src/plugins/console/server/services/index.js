"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "HavenaskLegacyConfigService", {
  enumerable: true,
  get: function () {
    return _havenask_legacy_config_service.HavenaskLegacyConfigService;
  }
});
Object.defineProperty(exports, "SpecDefinitionsService", {
  enumerable: true,
  get: function () {
    return _spec_definitions_service.SpecDefinitionsService;
  }
});

var _havenask_legacy_config_service = require("./havenask_legacy_config_service");

var _spec_definitions_service = require("./spec_definitions_service");