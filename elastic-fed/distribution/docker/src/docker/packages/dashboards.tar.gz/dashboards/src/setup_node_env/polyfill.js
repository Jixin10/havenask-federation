"use strict";

require("core-js/modules/es.symbol.description");

require("core-js/modules/es.symbol.match-all");

require("core-js/modules/es.array.flat");

require("core-js/modules/es.array.flat-map");

require("core-js/modules/es.array.unscopables.flat");

require("core-js/modules/es.array.unscopables.flat-map");

require("core-js/modules/es.math.hypot");

require("core-js/modules/es.object.from-entries");

require("core-js/modules/es.promise.all-settled");

require("core-js/modules/es.string.match-all");

require("core-js/modules/web.queue-microtask");